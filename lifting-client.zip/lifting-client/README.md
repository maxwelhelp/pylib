# Lifting Library Client

Геометрическая библиотека для универсального анализа данных.

## Установка

```bash
pip install -r requirements.txt
```

## Настройка

```python
from tasks import use_remote

# Подключение к API (обязательно!)
use_remote(
    api_key="your-api-key",
    base_url="https://api.lifting.io"
)
```

## Использование

### Детекция аномалий

```python
from tasks import AnomalyDetector
import numpy as np

# Данные (ваши фичи)
data = np.random.randn(100, 10)

detector = AnomalyDetector(threshold_sigma=2.0)
detector.fit(data)
results = detector.predict(new_data)

for r in results:
    if r.is_anomaly:
        print(f"Аномалия! Расстояние: {r.distance_deg:.1f}°")
```

### Классификация

```python
from tasks import Classifier

classifier = Classifier()
classifier.fit(train_data, labels)
predictions = classifier.predict(test_data)
```

### Доменные анализаторы

```python
from domains import ECGAnalyzer, DNAAnalyzer, AudioAnalyzer

# ECG
ecg = ECGAnalyzer(fs=500)
ecg.fit_anomaly(normal_ecg)
anomalies = ecg.detect_anomalies(patient_ecg)

# DNA
dna = DNAAnalyzer(k=4)
dna.fit_classifier(sequences, labels)
result = dna.classify(new_sequence)

# Audio
audio = AudioAnalyzer(fs=16000)
shapes = audio.process(audio_signal)
```

### Свой домен

```python
from domains.base import BaseDomainAnalyzer

class MyAnalyzer(BaseDomainAnalyzer):
    default_config = {'window_size': 100}

    def preprocess(self, data):
        # Разбивка на сегменты
        return segments

    def extract_features(self, segment):
        # Извлечение фичей
        return {'feature1': ..., 'feature2': ...}
```

## API ключи

Получить ключ: https://lifting.io/keys

| Тариф | Лимит | Цена |
|-------|-------|------|
| Free | 100/мин | Бесплатно |
| Pro | 1000/мин | $29/мес |
| Enterprise | 10000/мин | Custom |

## Лицензия

Proprietary - требуется API ключ.
