"""
Lifting Library Client v2.0

Геометрическая библиотека для анализа данных.
Работает через API - математика скрыта на сервере.

Быстрый старт:
    >>> from tasks import use_remote, AnomalyDetector
    >>> use_remote(api_key="your-key", base_url="https://api.lifting.io")
    >>>
    >>> detector = AnomalyDetector()
    >>> detector.fit(shapes)
    >>> results = detector.predict(new_data)
"""

__version__ = "2.0.0"

from .client import LiftingClient

__all__ = ['LiftingClient', '__version__']
