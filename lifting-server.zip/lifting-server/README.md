# Lifting API Server

Приватный сервер с математическим ядром.

## Быстрый старт

```bash
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

## Docker

```bash
docker build -t lifting-api .
docker run -d -p 8000:8000 \
  -e API_KEYS="demo-key,prod-key-123" \
  -e DEFAULT_RATE_LIMIT=100 \
  lifting-api
```

## Конфигурация

Переменные окружения:

```bash
# API ключи
API_KEYS=demo-key,prod-key-abc,enterprise-xyz

# Rate limits
DEFAULT_RATE_LIMIT=100
PREMIUM_RATE_LIMIT=1000
ENTERPRISE_RATE_LIMIT=10000

# Премиум ключи
PREMIUM_KEYS=prod-key-abc
ENTERPRISE_KEYS=enterprise-xyz

# Redis (для кластера)
REDIS_URL=redis://localhost:6379
```

## Endpoints

| Endpoint | Описание |
|----------|----------|
| `POST /geometry/normalize` | Нормализация → shapes |
| `POST /geometry/distance` | Геодезические расстояния |
| `POST /geometry/centroid` | Центроид |
| `POST /sync/compute` | SyncLifting метрики |
| `POST /sync/dominant` | Доминирующие метрики |
| `POST /batch` | Batch операции |
| `GET /health` | Health check |

## Масштабирование

```yaml
# docker-compose.yml
services:
  api:
    image: lifting-api
    deploy:
      replicas: 10
    environment:
      - REDIS_URL=redis://redis:6379

  redis:
    image: redis:7-alpine
```

## Безопасность

- HTTPS обязателен в production
- API ключи через X-API-Key header
- Rate limiting по ключу
- Никаких секретов в логах
